./' + tid + '?page=' + pg;
    let html = await request(link);
    let  = load(html);
    let items = ('div.item-box ul li');
    let videos = _.map(items, (item) => {
        let a = (item).find('a:first')[0];
        let img = (item).find('img:first')[0];
        return {
            vod_id: a.attribs.href,
            vod_name: a.attribs.title,
            vod_pic: img.attribs['data-original'],
            vod_remarks: '',
        };
    });
    let hasMore = ('ul.pagination > li > a:contains(»)').length > 0;
    let pgCount = hasMore ? parseInt(pg) + 1 : parseInt(pg);
    return JSON.stringify({
        page: parseInt(pg),
        pagecount: pgCount,
        limit: 16,
        total: 16 * pgCount,
        list: videos,
    });
}

async function detail(id) {
    let vod = {
        vod_id: id,
        vod_remarks: '',
    };
    let playlist = ['观看视频' + '' + id];
    vod.vod_play_from = '道长在线';
    vod.vod_play_url = playlist.join('#');
    return JSON.stringify({
        list: [vod],
    });
}

async function play(flag, id, flags) {
    let html = await request(id);
    let  = load(html);
    let playUrl = ('div.video-play-box').find('video:first')[0].attribs.src + '#.mp4';
    return JSON.stringify({
        parse: 0,
        url: playUrl,
    });
}

async function search(wd, quick, pg) {
    return '{}';
}

export function __jsEvalReturn() {
    return {
        init: init,
        home: home,
        homeVod: homeVod,
        category: category,
        detail: detail,
        play: play,
        search: search,
    };
}