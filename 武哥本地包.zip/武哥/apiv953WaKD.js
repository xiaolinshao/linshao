./ src="(.*?)'/)[1];
    var purl = paurl + url + '&next=' + next + '&id=' + id + '&nid=' + nid;
    var playUrl = await request(purl);
    playUrl = playUrl.match(/var .* = '(.*?)'/)[1];
    // console.debug('libvio playUrl =====>' + playUrl); // js_debug.log
    return JSON.stringify({
        parse: 0,
        url: playUrl,
    });
}

async function search(wd, quick) {
    var data = JSON.parse(await request(host + '/index.php/ajax/suggest?mid=1&wd=' + wd + '&limit=50')).list;
    var videos = [];
    for (const vod of data) {
        videos.push({
            vod_id: vod.id,
            vod_name: vod.name,
            vod_pic: vod.pic,
            vod_remarks: '',
        });
    }
    return JSON.stringify({
        list: videos,
        limit: 50,
    });
}

export function __jsEvalReturn() {
    return {
        init: init,
        home: home,
        homeVod: homeVod,
        category: category,
        detail: detail,
        play: play,
        search: search,
    };
}