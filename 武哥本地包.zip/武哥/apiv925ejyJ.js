./search_res_3362__' + tid + '_' + pg + '_' + (extend.by || '') + '.html' + (extend.age || '');
    const html = await request(link);
    const  = load(html);
    const items = ('body div.bj-col4:has(h3)');
    let videos = _.map(items, (it) => {
        const a = (it).find('a:first')[0];
        const img = (it).find('img:first')[0];
        const remarks = (it).find('span.played')[0];
        return {
            vod_id: a.attribs.href,
            vod_name: a.attribs.title,
            vod_pic: img.attribs['data-original'],
            vod_remarks: remarks.children[0].data || '',
        };
    });
    const hasMore = ('div.pub_paging > a:contains(下一页)').length > 0;
    const pgCount = hasMore ? parseInt(pg) + 1 : parseInt(pg);
    return JSON.stringify({
        page: parseInt(pg),
        pagecount: pgCount,
        limit: 30,
        total: 30 * pgCount,
        list: videos,
    });
}

async function detail(id) {
    const vod = {
        vod_id: id,
        vod_remarks: "",
    };
    const playlist = ["点击播放" + "$" + vod.vod_id];
    vod.vod_play_from = "道长在线";
    vod.vod_play_url = playlist.join("#"./m_ajax?q=' + wd + '&p=' + pg + '&typeId=3362')).body;
    let videos = _.map(data.result, (it) => {
        return {
            vod_id: it.playUrl,
            vod_name: it.resourceName,
            vod_pic: it.imageUrl,
            vod_remarks: it.clickNumStr || '',
        }
    });
    return JSON.stringify({
        page: parseInt(pg),
        pagecount: data.pageCount,
        limit: 30,
        total: data.rowCount,
        list: videos,
    });
}

function buildUrl(url, obj) {
    obj = obj || {};
    if (url.indexOf('?') < 0) {
        url += '?'
    }
    let param_list = [];
    let keys = Object.keys(obj);
    keys.forEach(it => {
        param_list.push(it + '=' + obj[it])
    });
    let prs = param_list.join('&');
    if (keys.length > 0 && !url.endsWith('?')) {
        url += '&'
    }
    url += prs;
    return url
}

export function __jsEvalReturn() {
    return {
        init: init,
        home: home,
        homeVod: homeVod,
        category: category,
        detail: detail,
        play: play,
        search: search,
    };
}