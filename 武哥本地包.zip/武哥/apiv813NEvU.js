./' + id];
    vod.vod_play_from = "道长在线";
    vod.vod_play_url = playlist.join('#');
    return JSON.stringify({
        list: [vod],
    });
}

async function play(flag, id, flags) {
    const html = await request(id);
    const $ = load(html);
    const pvideo = $("body mip-search-video[video-src*=http]");
    const purl = pvideo[0].attribs['video-src'];
    // console.debug('兔小贝 purl =====>' + purl); // js_debug.log
    return JSON.stringify({
        parse: 0,
        url: purl,
    });
}

async function search(wd, quick) {
    const link = HOST + "/search/" + wd;
    const html = await request(link);
    const $ = load(html);
    const list = $("div.list-con > div.items");
    let videos = _.map(list, (it) => {
        const a = $(it).find("a:first")[0];
        const img = $(it).find("mip-img:first")[0];
        const tt = $(it).find("p:first")[0];
        const remarks = $(it).find("p")[1];
        return {
            vod_id: a.attribs.href.replace(/.*?\/play\/(.*)/g, '$1'),
            vod_name: tt.children[0].data,
            vod_pic: img.attribs["src"],
            vod_remarks: remarks.children[0].data || "",
        };
    });
    return JSON.stringify({
        list: videos,
        land: 1,
        ratio: 1.78,
    });
}

export function __jsEvalReturn() {
    return {
        init: init,
        home: home,
        homeVod: homeVod,
        category: category,
        detail: detail,
        play: play,
        search: search,
    }
}